<!DOCTYPE html>
<html>
<head>
	<!--  Librerias -->
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous" />
	<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">
	<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
	<scrip src="https://code.jquery.com/jquery-3.5.1.js"></scrip>
	<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>
	<title> Index</title>
</head>
<style type="text/css">
	/* HEADER */
	.upper-menu .nav-link {
		font-size: 15px;
		font-weight: bold;
	}
	.nav a,
	.dropbtn {
		padding: 14px 16px;
	}
	#icon-mobile .fa{
		color:#FFFF;
	}

	.main-menu {
		background: #014c86;
	}
	.main-menu .nav-link {
		color: #fff;
		font-size: 17px;
	}
	.header-container {
		position: relative;
	}
	.bgContainer .header-bg {
		width: 100%;
	}
	.main-menu li {
		display: inline-block;
		padding: 0 10px;
	}
	.nav a:hover,
	li a:hover {
		background-color: #006fb7;
		color: #fff;
	}
	.logoContainer img {
		width: auto;
		height: 80px;
	}
	.header-bg.h-115 {
		height: 115px !important;
	}
	.navbar-expand-lg .navbar-nav .dropdown-menu {
		background-color: #958b8b3b;
	}

</style>
<body>
<div class="container-fluid">
	<!-- HEADER -->
	<header>
		<!-- LOGO -->
		<div class="header-container">
			<div class="row">
				<div class="col-12 col-sm-12 col-md-5 col-lg-5 logoContainer text-center py-3">
					<a href="#"><img src="<?php echo base_url("resources/img/logo.png") ?>" class="logo"/></a>
				</div>
			</div>
		</div>
		<!-- MAIN MENU -->
		<div class="row main-menu">
			<div class="col-12 col-sm-12 col-md-12 col-lg-12">
				<div>
					<nav class="navbar nav navbar-expand-lg p-0">
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
							<span id="icon-mobile"> <i class="fa fa-bars" aria-hidden="true"></i></span>
						</button>
						<div data-hover="dropdown" class="collapse navbar-collapse justify-content-center" id="navbarNav">
							<ul class="navbar-nav">
								<li class="nav-item active">
									<a class="nav-link" href="#">Inicio</a>
								</li>
								<li class="nav-item dropdown">
									<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										Instituciones
									</a>
									<div class="dropdown-menu p-0 m-0" aria-labelledby="navbarDropdown">
										<a class="dropdown-item" href="#">Item 1</a>
										<a class="dropdown-item" href="#">Item 2</a>
									</div>
								</li>
								<li class="nav-item dropdown">
									<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										Documentos
									</a>
									<div class="dropdown-menu p-0 m-0" aria-labelledby="navbarDropdown">
										<a class="dropdown-item" href="#">Item 1</a>
										<a class="dropdown-item" href="#">Item 2</a>
									</div>
								</li>
								<li class="nav-item dropdown">
									<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										Comunicaciones
									</a>
									<div class="dropdown-menu p-0 m-0" aria-labelledby="navbarDropdown">
										<a class="dropdown-item" href="#">Item 1</a>
										<a class="dropdown-item" href="#">Item 2</a>
									</div>
								</li>

								<li class="nav-item lista">
									<a class="nav-link" href="#">Contáctenos</a>
								</li>
							</ul>
						</div>
					</nav>
				</div>
			</div>
		</div>
	</header>
	<!-- CONTENT -->
	<table id="dataPrueba">
		<thead>
		<th>ID</th>
		<th>NOMBRE</th>
		</thead>
		<tbody>
			<tr>
				<td>041114</td>
				<td>Guillermo Jandres</td>
			</tr>
		</tbody>
	</table>

	<!---->
</div>
</body>
<footer>
</footer>
</html>
<script>
	$(document).ready(function () {

		$("#dataPrueba").dataTable();

	});

	//Ajax

	/*

	$(document).ready(function() {
    $('#example').DataTable( {
        "ajax": "../../../../examples/ajax/data/objects.txt",
        "columns": [
            { "data": "name" },
            { "data": "position" },
            { "data": "office" },
            { "data": "extn" },
            { "data": "start_date" },
            { "data": "salary" }
        ]
    } );
} );

	*/

</script>
