<?php
/**
 * Created by PhpStorm.
 * User: Jandres
 * Date: 31/8/2020
 * Time: 12:31
 */

class ExampleModel extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
		$this->load->database();

	}


	public function getAllClientes($idCliente = null){
		$this->db->select("*");
		$this->db->from($this->table);
		if ($idCliente!=null){
			$this->db->where("id",$idCliente);
		}
		$query = $this->db->get();
		return $query->result();

	}

	public function save_cliente($data){

		$this->db->insert('NOMBREDELATABLAENMAYUSCULA',$data);
		return $this->db->insert_id();

	}


	public function update_cliente($where, $data){
		$this->db->update($this->table,$data,$where);
		return $this->db->affected_rows();
	}


}
